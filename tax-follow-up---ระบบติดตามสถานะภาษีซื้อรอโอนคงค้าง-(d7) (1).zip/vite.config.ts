
import { defineConfig } from 'vite';
import react from '@vitejs/plugin-react';

export default defineConfig({
  plugins: [react()],
  // เปลี่ยน 'repository-name' เป็นชื่อ repository ของคุณบน GitHub เช่น '/tax-ai/'
  // หากใช้ custom domain ให้ใช้ '/'
  base: './', 
  build: {
    outDir: 'dist',
  }
});
